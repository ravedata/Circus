from chatterbot.output.output_adapter import OutputAdapter
import requests
from array import *
from chatterbot.conversation import statement
## Call the weather package  here
class CustomOutputAdapterrail(OutputAdapter):
    """
    A generic class that can be overridden by a subclass to provide extended
    functionality, such as delivering a response to an API endpoint.
    """

    def process_response(self, statement, session_id=None):
        """
        Override this method in a subclass to implement customized functionality.

        :param statement: The statement that the chat bot has produced in response to some input.

        :param session_id: The unique id of the current chat session.

        :returns: The response statement.
        """
       # statement.text="Overridden";

        #statement.text = "weather";
        if 'pnr' not in statement.text:
            return statement

        else:
            a = "";
            res = [];
            r = requests.get(
                'http://api.railwayapi.com/v2/pnr-status/pnr/6533543051/apikey/94cme36em6/')
            json_object = r.json()
            #pnr_jdate = json_object['doj']
            #pnr_trainno = json_object['train']['number']
            #pnr_trainname = json_object['to_station']['name']
            #a = str(pnr_jdate) + '<br>' + str(pnr_trainno) + '<br>' + str(pnr_trainname) + '<br>'
            #print(r.text)
            statement.text = r.text
            return statement

