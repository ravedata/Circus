from chatterbot.output.output_adapter import OutputAdapter
import requests
from chatterbot.conversation import statement
## Call the weather package  here
class CustomOutputAdapternews(OutputAdapter):
    """
    A generic class that can be overridden by a subclass to provide extended
    functionality, such as delivering a response to an API endpoint.
    """

    def process_response(self, statement, session_id=None):
        """
        Override this method in a subclass to implement customized functionality.

        :param statement: The statement that the chat bot has produced in response to some input.

        :param session_id: The unique id of the current chat session.

        :returns: The response statement.
        """
       # statement.text="Overridden";

        #statement.text = "weather";
        if 'news' not in statement.text:
            return statement

        else:
            b = "";
            news = [];
            r = requests.get(
                'https://newsapi.org/v1/articles?source=the-times-of-india&sortBy=top&apiKey=82033ea854e846d9bfdf333d3eff8b3a')
            json_object = r.json()
            print(r.text)
            #for i in range(0,5):
            for i in range(0, 5):
                news_title = str(json_object['articles'][i]['title'])
                news_url = str(json_object['articles'][i]['url'])
                a = '<b>Title : </b>' + str(news_title) + '<br>' + '<b>Link : </b>' + '<a href = "' + news_url + '"' + 'target="_blank">Click here</a>' + '<br>'
                b = b + str(a) + '<br>'
                print(news_url)
            statement.text = '<b>Top 5 Headlines: </b>' + '<br>' + '<br>' + str(b)
            #statement.text = r.text
            return statement

