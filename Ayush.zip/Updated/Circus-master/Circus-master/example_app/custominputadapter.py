from __future__ import unicode_literals
from chatterbot.input.input_adapter import InputAdapter


class CustomInputAdapter(InputAdapter):
    """
    This is an abstract class that represents the
    interface that all input adapters should implement.
    """

    def process_input(self, *args, **kwargs):
        """
        Returns a statement object based on the input source.
        """
        raise self.AdapterMethodNotImplementedError()

    def process_input_statement(self, *args, **kwargs):
        """
        Return an existing statement object (if one exists).
        """
        input_statement = self.process_input(*args, **kwargs)
        self.logger.info('Recieved input statement: {}'.format(input_statement.text))
        if 'hi' in input_statement.text:
            input_statement.text = 'hello'
        print(input_statement)

        existing_statement = self.chatbot.storage.find(input_statement.text)

        if existing_statement:
            self.logger.info('"{}" is a known statement'.format(input_statement.text))
            input_statement = existing_statement
            print(input_statement)


        else:
            self.logger.info('"{}" is not a known statement'.format(input_statement.text))
            print(input_statement)

        return input_statement

