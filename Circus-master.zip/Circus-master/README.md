# Circus

This is a chatterbot implementation via django.


Status :  We are still in progress to learn how to train a chatterbot.

Task for team :-- please learn and implement the training of chatterbot in existing example.
